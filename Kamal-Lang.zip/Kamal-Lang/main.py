class KamalLang:
    def __init__(self):
        self.variables = {}

    def speak(self, message):
        """Handle KAMAL.SPEAK commands"""
        print(f"🎬 Kamal says: {message}")

    def parse_value(self, value):
        """Parse different value types"""
        value = value.strip()

        # Boolean values
        if value == "True":
            return True
        elif value == "False":
            return False

        # String values (with quotes)
        if value.startswith('"') and value.endswith('"'):
            return value[1:-1]  # Remove quotes

        # Numeric values
        try:
            if '.' in value:
                return float(value)
            else:
                return int(value)
        except ValueError:
            # If it's a variable reference
            return self.variables.get(value, value)

    def evaluate_expression(self, expr):
        """Evaluate expressions with variables and operations"""
        expr = expr.strip()

        # Handle string concatenation
        if '+' in expr and any('"' in part or 'str(' in part for part in expr.split('+')):
            parts = []
            for part in expr.split('+'):
                part = part.strip()
                if part.startswith('str(') and part.endswith(')'):
                    var_name = part[4:-1].strip()
                    if var_name in self.variables:
                        parts.append(str(self.variables[var_name]))
                    else:
                        parts.append(str(var_name))
                elif part.startswith('"') and part.endswith('"'):
                    parts.append(part[1:-1])
                elif part in self.variables:
                    parts.append(str(self.variables[part]))
                else:
                    parts.append(str(part))
            return ''.join(parts)

        # Handle arithmetic operations
        if '*' in expr:
            parts = expr.split('*')
            if len(parts) == 2:
                left = parts[0].strip()
                right = parts[1].strip()
                left_val = self.variables.get(left, self.parse_value(left))
                right_val = self.variables.get(right, self.parse_value(right))
                return left_val * right_val

        # Handle logical operations
        if 'AND' in expr:
            parts = expr.split('AND')
            if len(parts) == 2:
                left = parts[0].strip()
                right = parts[1].strip()
                left_val = self.variables.get(left, self.parse_value(left))
                right_val = self.variables.get(right, self.parse_value(right))
                return left_val and right_val

        # Single value or variable
        return self.parse_value(expr)

    def execute_line(self, line):
        """Execute a single line of KamalLang code"""
        line = line.strip()

        # Skip empty lines and comments
        if not line or line.startswith('#'):
            return

        # KAMAL.SPEAK command
        if line.startswith('KAMAL.SPEAK'):
            message_part = line[11:].strip()
            if message_part.startswith('"') and message_part.endswith('"'):
                # Direct string
                message = message_part[1:-1]
                self.speak(message)
            else:
                # Expression that needs evaluation
                result = self.evaluate_expression(message_part)
                self.speak(str(result))

        # INTELLECT variable assignment
        elif line.startswith('INTELLECT'):
            assignment = line[9:].strip()
            if '=' in assignment:
                var_name, value_expr = assignment.split('=', 1)
                var_name = var_name.strip()
                value_expr = value_expr.strip()
                self.variables[var_name] = self.evaluate_expression(value_expr)

        # IF statements
        elif line.startswith('IF'):
            # Parse IF condition THEN action
            if 'THEN' in line:
                condition_part = line[2:line.index('THEN')].strip()
                action_part = line[line.index('THEN') + 4:].strip()

                # Evaluate condition using safer eval approach
                try:
                    # Replace variable names with their values for evaluation
                    condition_for_eval = condition_part
                    for var_name, var_value in self.variables.items():
                        condition_for_eval = condition_for_eval.replace(var_name, str(var_value))

                    # Handle boolean values
                    condition_for_eval = condition_for_eval.replace('True', 'True').replace('False', 'False')

                    # Evaluate the condition
                    condition_result = eval(condition_for_eval)
                except:
                    condition_result = self.evaluate_expression(condition_part)

                # Execute action if condition is true
                if condition_result:
                    self.execute_line(action_part)

    def run_program(self, code):
        """Run a complete KamalLang program"""
        lines = code.strip().split('\n')
        for line in lines:
            self.execute_line(line)

# KamalLang program
kamal_code = '''
# Welcome to KamalLang!
# A programming language inspired by the legendary Kamal Haasan

KAMAL.SPEAK "Vanakkam! Welcome to KamalLang - Where Art Meets Code!"

INTELLECT age = 70
INTELLECT films = 230
INTELLECT thug_life = True

IF age > 60 THEN KAMAL.SPEAK "Vetri Nichayam! (Success is certain!)"
IF films > 200 THEN KAMAL.SPEAK "Indian cinema legend!"
IF thug_life AND age > 50 THEN KAMAL.SPEAK "Thug Life: Thinking, Understanding, Growing!"

INTELLECT fans = 1000000
INTELLECT new_fans = fans * 2
KAMAL.SPEAK "Kamal has millions of fans!"

KAMAL.SPEAK "Kamal Haasan is " + str(age) + " years young!"
'''

if __name__ == "__main__":
    print("🎭 Starting KamalLang Interpreter...")
    print("=" * 50)

    interpreter = KamalLang()
    interpreter.run_program(kamal_code)

    print("=" * 50)
    print("🎬 KamalLang execution completed!")