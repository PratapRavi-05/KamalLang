
#!/usr/bin/env python3
"""
Test suite for KamalLang - Ensuring quality code worthy of Kamal Haasan
"""

import unittest
import io
import sys
from contextlib import redirect_stdout
from kamal_interpreter import KamalLang

class TestKamalLang(unittest.TestCase):
    
    def setUp(self):
        """Set up test fixtures before each test method."""
        self.interpreter = KamalLang()
        self.captured_output = io.StringIO()
    
    def capture_output(self, code):
        """Helper method to capture output from KamalLang execution"""
        with redirect_stdout(self.captured_output):
            self.interpreter.run_program(code)
        return self.captured_output.getvalue()
    
    def test_basic_speak(self):
        """Test basic KAMAL.SPEAK functionality"""
        code = 'KAMAL.SPEAK "Vanakkam!"'
        output = self.capture_output(code)
        self.assertIn("Vanakkam!", output)
        self.assertIn("🎬 Kamal says:", output)
    
    def test_variable_declaration(self):
        """Test INTELLECT variable declaration"""
        code = '''
        INTELLECT age = 70
        KAMAL.SPEAK "Test completed"
        '''
        self.capture_output(code)
        self.assertEqual(self.interpreter.variables['age'], 70)
    
    def test_conditional_execution(self):
        """Test IF/THEN conditional logic"""
        code = '''
        INTELLECT age = 70
        IF age > 60 THEN KAMAL.SPEAK "Senior citizen"
        '''
        output = self.capture_output(code)
        self.assertIn("Senior citizen", output)
    
    def test_arithmetic_operations(self):
        """Test arithmetic operations in expressions"""
        code = '''
        INTELLECT fans = 1000000
        INTELLECT new_fans = fans * 2
        '''
        self.capture_output(code)
        self.assertEqual(self.interpreter.variables['new_fans'], 2000000)
    
    def test_string_concatenation(self):
        """Test string concatenation with variables"""
        code = '''
        INTELLECT age = 70
        KAMAL.SPEAK "Kamal is " + str(age) + " years young!"
        '''
        output = self.capture_output(code)
        self.assertIn("Kamal is 70 years young!", output)
    
    def test_boolean_logic(self):
        """Test boolean operations"""
        code = '''
        INTELLECT is_actor = True
        INTELLECT age = 70
        IF is_actor AND age > 60 THEN KAMAL.SPEAK "Veteran actor"
        '''
        output = self.capture_output(code)
        self.assertIn("Veteran actor", output)
    
    def test_comments_and_empty_lines(self):
        """Test that comments and empty lines are handled correctly"""
        code = '''
        # This is a comment
        INTELLECT test = 42
        
        # Another comment
        KAMAL.SPEAK "Comments work!"
        '''
        output = self.capture_output(code)
        self.assertIn("Comments work!", output)
        self.assertEqual(self.interpreter.variables['test'], 42)
    
    def test_error_handling(self):
        """Test error handling for invalid syntax"""
        # Reset captured output
        self.captured_output = io.StringIO()
        
        code = 'INVALID.COMMAND "This should fail"'
        output = self.capture_output(code)
        self.assertIn("KamalError", output)
    
    def test_complex_program(self):
        """Test a complex program with multiple features"""
        code = '''
        # KamalLang comprehensive test
        INTELLECT age = 70
        INTELLECT films = 230
        INTELLECT is_legend = True
        
        IF age > 60 THEN KAMAL.SPEAK "Still going strong!"
        IF films > 200 AND is_legend THEN KAMAL.SPEAK "Cinema legend!"
        
        INTELLECT total_experience = age - 5
        KAMAL.SPEAK "Experience: " + str(total_experience) + " years"
        '''
        output = self.capture_output(code)
        
        self.assertIn("Still going strong!", output)
        self.assertIn("Cinema legend!", output)
        self.assertIn("Experience: 65 years", output)

if __name__ == '__main__':
    print("🎭 Running KamalLang Test Suite...")
    print("=" * 50)
    
    unittest.main(verbosity=2)
    
    print("=" * 50)
    print("🎬 Tests completed! Kamal would be proud! 🎭")
