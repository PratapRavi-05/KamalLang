#!/bin/bash
# KamalLang Installation Script
echo "🎭 Installing KamalLang v1.1.0..."

# Check if Python 3 is available
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required but not installed"
    exit 1
fi

# Make interpreter executable
chmod +x kamal_interpreter.py

# Optional: Install as system package
read -p "Install KamalLang system-wide? (y/n): " install_system
if [[ $install_system == "y" || $install_system == "Y" ]]; then
    echo "📦 Installing KamalLang package..."
    python3 setup.py install --user
    echo "✅ KamalLang installed! Use 'kamallang script.kamal' to run programs"
else
    echo "✅ KamalLang ready! Use 'python3 kamal_interpreter.py script.kamal' to run programs"
fi

echo "🎬 Installation completed! Vanakkam!"
