
#!/usr/bin/env python3
"""
Setup script for KamalLang - A tribute to Kamal Haasan through code.
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="kamallang",
    version="1.0.0",
    author="PratapRavi-05",
    description="A beginner-friendly programming language inspired by Kamal Haasan",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/PratapRavi-05/KamalLang",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Education",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Education",
        "Topic :: Software Development :: Interpreters",
    ],
    python_requires=">=3.7",
    entry_points={
        "console_scripts": [
            "kamallang=kamal_interpreter:main",
        ],
    },
    keywords="programming-language education kamal-haasan tamil cinema",
    project_urls={
        "Bug Reports": "https://github.com/PratapRavi-05/KamalLang/issues",
        "Source": "https://github.com/PratapRavi-05/KamalLang",
        "Replit Demo": "https://replit.com/@YourUsername/KamalLang",
    },
)
