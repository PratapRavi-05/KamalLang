
"""
KamalLang Interpreter v1.1 - A Python-based educational programming language
inspired by the legendary actor Kamal Haasan.

Syntax Features:
- KAMAL.SPEAK for print statements with expression support
- INTELLECT for variable declaration
- IF/THEN for conditionals with complex expressions
- Arithmetic and logical operations
- String concatenation with variables
- Uses Tamil cinema references and Kamal's philosophy
"""

import sys
import re

class KamalLang:
    def __init__(self):
        self.variables = {}
        self.kamal_quotes = [
            "Life is beautiful, keep learning!",
            "Art is freedom, programming is art!",
            "Intha world-ula enna panna mudiyum!",
            "Hey Ram! Let's code with wisdom.",
            "Thug Life means Thinking, Understanding, Growing!"
        ]

    def speak(self, message):
        """Handle KAMAL.SPEAK commands with Kamal's flair"""
        print(f"🎬 Kamal says: {message}")

    def parse_value(self, value):
        """Parse different value types with enhanced support"""
        value = value.strip()

        # Boolean values
        if value == "True":
            return True
        elif value == "False":
            return False

        # String values (with quotes)
        if value.startswith('"') and value.endswith('"'):
            return value[1:-1]  # Remove quotes

        # Numeric values
        try:
            if '.' in value:
                return float(value)
            else:
                return int(value)
        except ValueError:
            # If it's a variable reference
            return self.variables.get(value, value)

    def evaluate_expression(self, expr):
        """Evaluate expressions with enhanced support for complex operations"""
        expr = expr.strip()

        # Handle string concatenation with variables
        if '+' in expr and any('"' in part or 'str(' in part for part in expr.split('+')):
            parts = []
            current_part = ""
            in_quotes = False
            
            i = 0
            while i < len(expr):
                char = expr[i]
                if char == '"':
                    in_quotes = not in_quotes
                    current_part += char
                elif char == '+' and not in_quotes:
                    if current_part.strip():
                        parts.append(current_part.strip())
                    current_part = ""
                else:
                    current_part += char
                i += 1
            
            if current_part.strip():
                parts.append(current_part.strip())
            
            result_parts = []
            for part in parts:
                part = part.strip()
                if part.startswith('str(') and part.endswith(')'):
                    var_name = part[4:-1].strip()
                    if var_name in self.variables:
                        result_parts.append(str(self.variables[var_name]))
                    else:
                        result_parts.append(str(var_name))
                elif part.startswith('"') and part.endswith('"'):
                    result_parts.append(part[1:-1])
                elif part in self.variables:
                    result_parts.append(str(self.variables[part]))
                else:
                    result_parts.append(str(part))
            return ''.join(result_parts)

        # Handle arithmetic operations
        for op in ['*', '/', '+', '-']:
            if op in expr:
                parts = expr.split(op, 1)
                if len(parts) == 2:
                    left = parts[0].strip()
                    right = parts[1].strip()
                    left_val = self.variables.get(left, self.parse_value(left))
                    right_val = self.variables.get(right, self.parse_value(right))
                    
                    try:
                        if op == '*':
                            return left_val * right_val
                        elif op == '/':
                            return left_val / right_val
                        elif op == '+':
                            return left_val + right_val
                        elif op == '-':
                            return left_val - right_val
                    except (TypeError, ZeroDivisionError) as e:
                        print(f"🎬 KamalError: Mathematical mishap! {str(e)}")
                        return 0

        # Handle logical operations
        if 'AND' in expr:
            parts = expr.split('AND')
            if len(parts) == 2:
                left = parts[0].strip()
                right = parts[1].strip()
                left_val = self.variables.get(left, self.parse_value(left))
                right_val = self.variables.get(right, self.parse_value(right))
                return left_val and right_val

        # Single value or variable
        return self.parse_value(expr)

    def execute_line(self, line):
        """Execute a single line of KamalLang code with enhanced error handling"""
        line = line.strip()

        # Skip empty lines and comments
        if not line or line.startswith('#'):
            return

        try:
            # KAMAL.SPEAK command
            if line.startswith('KAMAL.SPEAK'):
                message_part = line[11:].strip()
                if message_part.startswith('"') and message_part.endswith('"'):
                    # Direct string
                    message = message_part[1:-1]
                    self.speak(message)
                else:
                    # Expression that needs evaluation
                    result = self.evaluate_expression(message_part)
                    self.speak(str(result))

            # INTELLECT variable assignment
            elif line.startswith('INTELLECT'):
                assignment = line[9:].strip()
                if '=' in assignment:
                    var_name, value_expr = assignment.split('=', 1)
                    var_name = var_name.strip()
                    value_expr = value_expr.strip()
                    self.variables[var_name] = self.evaluate_expression(value_expr)
                else:
                    print("🎬 KamalError: INTELLECT needs assignment with = operator")

            # IF statements with enhanced condition handling
            elif line.startswith('IF'):
                if 'THEN' in line:
                    condition_part = line[2:line.index('THEN')].strip()
                    action_part = line[line.index('THEN') + 4:].strip()

                    # Enhanced condition evaluation
                    try:
                        # Replace variable names with their values for evaluation
                        condition_for_eval = condition_part
                        for var_name, var_value in self.variables.items():
                            # Use word boundaries to avoid partial replacements
                            pattern = r'\b' + re.escape(var_name) + r'\b'
                            condition_for_eval = re.sub(pattern, str(var_value), condition_for_eval)

                        # Evaluate the condition safely
                        condition_result = eval(condition_for_eval)
                    except Exception as e:
                        print(f"🎬 KamalError: Cannot evaluate condition '{condition_part}' - {str(e)}")
                        return

                    # Execute action if condition is true
                    if condition_result:
                        self.execute_line(action_part)
                else:
                    print("🎬 KamalError: IF statements must end with THEN")

            else:
                print(f"🎬 KamalError: Unknown command '{line}'. Hey Ram! Check the syntax.")

        except Exception as e:
            print(f"🎬 KamalError: {str(e)} - Kamal says: 'Debug panna vendum!'")

    def run_program(self, code):
        """Run a complete KamalLang program with enhanced feedback"""
        lines = code.strip().split('\n')
        line_number = 0
        
        for line in lines:
            line_number += 1
            try:
                self.execute_line(line)
            except Exception as e:
                print(f"🎬 KamalError at line {line_number}: {str(e)}")

    def run_file(self, filename):
        """Run a KamalLang file with enhanced error reporting"""
        try:
            with open(filename, 'r', encoding='utf-8') as file:
                code = file.read()
            print(f"🎭 Running KamalLang file: {filename}")
            self.run_program(code)
        except FileNotFoundError:
            print(f"🎬 KamalError: File '{filename}' not found. Hey Ram! Check the path.")
        except UnicodeDecodeError:
            print(f"🎬 KamalError: Cannot read file '{filename}'. Check encoding.")
        except Exception as e:
            print(f"🎬 KamalError: {str(e)}")

    def get_random_quote(self):
        """Get a random Kamal quote for inspiration"""
        import random
        return random.choice(self.kamal_quotes)

def main():
    print("🎭 KamalLang Interpreter v1.1")
    print("=" * 50)
    
    if len(sys.argv) != 2:
        print("Usage: python kamal_interpreter.py script.kamal")
        print("\nExample KamalLang code:")
        print('INTELLECT age = 70')
        print('IF age > 60 THEN KAMAL.SPEAK "Still evolving as an actor and thinker!"')
        print('KAMAL.SPEAK "Kamal is " + str(age) + " years young!"')
        print("\nSupported features:")
        print("- Variables with INTELLECT")
        print("- Conditionals with IF/THEN") 
        print("- String concatenation")
        print("- Arithmetic operations")
        print("- Boolean logic")
        return
    
    filename = sys.argv[1]
    if not filename.endswith('.kamal'):
        print("🎬 KamalError: KamalLang files must have .kamal extension")
        return
    
    interpreter = KamalLang()
    interpreter.run_file(filename)
    
    print("=" * 50)
    print("🎬 KamalLang execution completed!")
    print(f"💭 Kamal's wisdom: {interpreter.get_random_quote()}")

if __name__ == "__main__":
    main()
